package com.example.data.repository

import android.content.Context
import com.example.data.firestore.FirestoreProvider
import com.example.data.firestore.OperationType
import com.example.data.firestore.handleFirestoreError
import com.example.data.model.BiweeklyQuota
import com.example.data.model.BranchOptions
import com.example.data.model.SalesMetricType
import com.example.utils.DateAndFormatters
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.tasks.await
import kotlin.math.roundToLong

/**
 * Independent repository operations for managing the administrator's supervision quota
 * and branch-level biweekly quotas without modifying the protected AppRepository.kt.
 */
class QuotaRepositoryExtensions(
    private val db: FirebaseFirestore
) {
    constructor(context: Context) : this(FirestoreProvider.getInstance(context))

    private val auth = Firebase.auth

    private fun requireUserId(): String =
        auth.currentUser?.uid
            ?: throw IllegalStateException("El usuario debe iniciar sesión con Google primero.")

    private fun buildQuotaDocId(periodId: String, branchName: String): String {
        val branchSlug = branchName.lowercase()
            .replace(Regex("[^a-z0-9]+"), "_")
            .trim('_')
            .ifBlank { "general" }
        return "quota_${periodId}_${branchSlug}".take(120)
    }

    /**
     * Saves either:
     * - The administrator's independent general quota (`branchName == ALL_BRANCHES_OPTION` and `!applyToAllIndividualBranches`)
     * - Individual branch quotas (`applyToAllIndividualBranches == true` or a specific branch),
     * NEVER summing or overwriting the administrator's independent general quota with branch totals.
     */
    suspend fun saveIndependentBiweeklyQuota(
        title: String,
        startDate: String,
        endDate: String,
        totalDays: Long,
        targetGlobalSales: Double,
        targetCreditSales: Double,
        targetNewCustomers: Long,
        targetAppMaOperations: Long,
        targetNewCustomerRequests: Long,
        branchName: String = BranchOptions.ALL_BRANCHES_OPTION,
        periodId: String = DateAndFormatters.biweeklyPeriodIdForIso(startDate),
        applyToAllIndividualBranches: Boolean = false
    ): Result<Unit> {
        val path = "biweekly_quotas"
        return try {
            val adminUid = requireUserId()
            val cleanTitle = title.trim()
            val cleanBranch = branchName.trim().ifBlank { BranchOptions.ALL_BRANCHES_OPTION }
            val cleanPeriodId = periodId.trim().ifBlank { DateAndFormatters.biweeklyPeriodIdForIso(startDate) }
            require(cleanTitle.length in 3..80) { "El nombre de la quincena debe tener entre 3 y 80 caracteres." }
            require(targetGlobalSales > 0.0) { "La meta de venta global debe ser mayor a 0." }
            require(totalDays in 1L..31L) { "La duración debe estar entre 1 y 31 días." }
            require(cleanBranch == BranchOptions.ALL_BRANCHES_OPTION || cleanBranch in BranchOptions.ALL_BRANCHES) {
                "Selecciona una sucursal válida."
            }

            val existingActive = db.collection(path)
                .whereEqualTo("active", true)
                .get()
                .await()

            val targetBranches: List<String> = if (cleanBranch == BranchOptions.ALL_BRANCHES_OPTION && applyToAllIndividualBranches) {
                // Apply exclusively to the individual branches; keep the admin's general supervision quota untouched.
                BranchOptions.ALL_BRANCHES
            } else {
                listOf(cleanBranch)
            }

            val targetBranchesSet = targetBranches.toSet()
            val targetDocIds = targetBranches.associateWith { buildQuotaDocId(cleanPeriodId, it) }

            val batch = db.batch()
            existingActive.documents.forEach { doc ->
                val docBranch = doc.getString("branchName")?.takeIf { it.isNotBlank() }
                    ?: BranchOptions.ALL_BRANCHES_OPTION
                val docStart = doc.getString("startDate") ?: ""
                val docPeriod = doc.getString("periodId")?.takeIf { it.isNotBlank() }
                    ?: if (docStart.length == 10) DateAndFormatters.biweeklyPeriodIdForIso(docStart) else cleanPeriodId
                val isTargetDoc = doc.id in targetDocIds.values
                if (!isTargetDoc && (docPeriod != cleanPeriodId || docBranch in targetBranchesSet)) {
                    batch.update(
                        doc.reference,
                        mapOf(
                            "active" to false,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                }
            }

            val safeGlobal = targetGlobalSales.coerceIn(0.01, 1_000_000_000.0)
            val safeCredit = targetCreditSales.coerceIn(0.0, 1_000_000_000.0)
            val safeCustomers = targetNewCustomers.coerceIn(0L, 100_000L)
            val safeAppMa = targetAppMaOperations.coerceIn(0L, 100_000L)
            val safeRequests = targetNewCustomerRequests.coerceIn(0L, 100_000L)

            val existingById = existingActive.documents.associateBy { it.id }
            for (targetBranch in targetBranches) {
                val docId = targetDocIds.getValue(targetBranch)
                val docRef = db.collection(path).document(docId)
                val existingSnap = existingById[docId] ?: docRef.get().await()

                if (existingSnap.exists()) {
                    batch.update(
                        docRef,
                        mapOf(
                            "title" to cleanTitle,
                            "startDate" to startDate,
                            "endDate" to endDate,
                            "totalDays" to totalDays,
                            "periodId" to cleanPeriodId,
                            "branchName" to targetBranch,
                            "targetGlobalSales" to safeGlobal,
                            "targetCreditSales" to safeCredit,
                            "targetNewCustomers" to safeCustomers,
                            "targetAppMaOperations" to safeAppMa,
                            "targetNewCustomerRequests" to safeRequests,
                            "active" to true,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                } else {
                    batch.set(
                        docRef,
                        mapOf(
                            "title" to cleanTitle,
                            "startDate" to startDate,
                            "endDate" to endDate,
                            "totalDays" to totalDays,
                            "periodId" to cleanPeriodId,
                            "branchName" to targetBranch,
                            "targetGlobalSales" to safeGlobal,
                            "targetCreditSales" to safeCredit,
                            "targetNewCustomers" to safeCustomers,
                            "targetAppMaOperations" to safeAppMa,
                            "targetNewCustomerRequests" to safeRequests,
                            "active" to true,
                            "createdBy" to adminUid,
                            "createdAt" to FieldValue.serverTimestamp(),
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                }
            }

            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    /**
     * Directly updates a single indicator target ("Meta") in the administrator's
     * independent general quota document in Firestore without affecting branch quotas.
     */
    suspend fun updateAdminGeneralIndicatorTarget(
        metric: SalesMetricType,
        newTargetValue: Double,
        baseGeneralQuota: BiweeklyQuota?
    ): Result<BiweeklyQuota> {
        val path = "biweekly_quotas"
        return try {
            val adminUid = requireUserId()
            when (metric) {
                SalesMetricType.GLOBAL_SALES -> {
                    require(newTargetValue > 0.0 && newTargetValue <= 1_000_000_000.0) {
                        "La meta de Venta global debe ser mayor a 0."
                    }
                }
                SalesMetricType.CREDIT_SALES -> {
                    require(newTargetValue >= 0.0 && newTargetValue <= 1_000_000_000.0) {
                        "La meta de Venta a crédito debe ser mayor o igual a 0."
                    }
                }
                SalesMetricType.NEW_CUSTOMERS,
                SalesMetricType.APP_MA_OPS,
                SalesMetricType.NEW_CUSTOMER_REQUESTS -> {
                    require(newTargetValue >= 0.0 && newTargetValue <= 100_000.0) {
                        "El objetivo de ${metric.titleEs} debe estar entre 0 y 100,000."
                    }
                }
            }

            val fallback = baseGeneralQuota ?: ProjectionCalculator.defaultGeneralQuotaPlaceholder()
            val periodId = fallback.effectivePeriodId
            val docId = buildQuotaDocId(periodId, BranchOptions.ALL_BRANCHES_OPTION)
            val docRef = db.collection(path).document(docId)
            val existingSnap = docRef.get().await()
            val existingObj = if (existingSnap.exists()) {
                existingSnap.toObject(BiweeklyQuota::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            } else {
                null
            }

            val seed = existingObj ?: fallback
            val updated = when (metric) {
                SalesMetricType.GLOBAL_SALES -> seed.copy(
                    id = docId,
                    branchName = BranchOptions.ALL_BRANCHES_OPTION,
                    periodId = periodId,
                    targetGlobalSales = newTargetValue
                )
                SalesMetricType.CREDIT_SALES -> seed.copy(
                    id = docId,
                    branchName = BranchOptions.ALL_BRANCHES_OPTION,
                    periodId = periodId,
                    targetCreditSales = newTargetValue
                )
                SalesMetricType.NEW_CUSTOMERS -> seed.copy(
                    id = docId,
                    branchName = BranchOptions.ALL_BRANCHES_OPTION,
                    periodId = periodId,
                    targetNewCustomers = newTargetValue.roundToLong().coerceIn(0L, 100_000L)
                )
                SalesMetricType.APP_MA_OPS -> seed.copy(
                    id = docId,
                    branchName = BranchOptions.ALL_BRANCHES_OPTION,
                    periodId = periodId,
                    targetAppMaOperations = newTargetValue.roundToLong().coerceIn(0L, 100_000L)
                )
                SalesMetricType.NEW_CUSTOMER_REQUESTS -> seed.copy(
                    id = docId,
                    branchName = BranchOptions.ALL_BRANCHES_OPTION,
                    periodId = periodId,
                    targetNewCustomerRequests = newTargetValue.roundToLong().coerceIn(0L, 100_000L)
                )
            }

            if (existingSnap.exists()) {
                val fieldUpdate = when (metric) {
                    SalesMetricType.GLOBAL_SALES -> "targetGlobalSales" to updated.targetGlobalSales
                    SalesMetricType.CREDIT_SALES -> "targetCreditSales" to updated.targetCreditSales
                    SalesMetricType.NEW_CUSTOMERS -> "targetNewCustomers" to updated.targetNewCustomers
                    SalesMetricType.APP_MA_OPS -> "targetAppMaOperations" to updated.targetAppMaOperations
                    SalesMetricType.NEW_CUSTOMER_REQUESTS -> "targetNewCustomerRequests" to updated.targetNewCustomerRequests
                }
                docRef.update(
                    mapOf(
                        fieldUpdate,
                        "branchName" to BranchOptions.ALL_BRANCHES_OPTION,
                        "periodId" to periodId,
                        "active" to true,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                val (defaultStart, defaultEnd) = DateAndFormatters.defaultBiweeklyRange()
                val start = updated.startDate.takeIf { it.length == 10 } ?: defaultStart
                val end = updated.endDate.takeIf { it.length == 10 } ?: defaultEnd
                val days = updated.totalDays.coerceIn(1L, 31L)
                val title = updated.title.trim().takeIf { it.length in 3..80 }
                    ?: DateAndFormatters.defaultBiweeklyTitle()

                docRef.set(
                    mapOf(
                        "title" to title,
                        "startDate" to start,
                        "endDate" to end,
                        "totalDays" to days,
                        "periodId" to periodId,
                        "branchName" to BranchOptions.ALL_BRANCHES_OPTION,
                        "targetGlobalSales" to updated.targetGlobalSales.coerceAtLeast(1.0),
                        "targetCreditSales" to updated.targetCreditSales.coerceAtLeast(0.0),
                        "targetNewCustomers" to updated.targetNewCustomers.coerceIn(0L, 100_000L),
                        "targetAppMaOperations" to updated.targetAppMaOperations.coerceIn(0L, 100_000L),
                        "targetNewCustomerRequests" to updated.targetNewCustomerRequests.coerceIn(0L, 100_000L),
                        "active" to true,
                        "createdBy" to adminUid,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }

            Result.success(updated)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "$path/${metric.name}")
            Result.failure(e)
        }
    }
}
