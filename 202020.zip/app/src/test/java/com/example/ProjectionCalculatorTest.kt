package com.example

import com.example.data.model.BiweeklyQuota
import com.example.data.model.BranchOptions
import com.example.data.model.DailySalesEntry
import com.example.data.model.ProjectionPace
import com.example.data.model.SalesMetricType
import com.example.data.model.UserProfile
import com.example.data.model.buildBranchSalesSummaries
import com.example.data.repository.ProjectionCalculator
import com.google.firebase.Timestamp
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ProjectionCalculatorTest {

    private val generalQuota = BiweeklyQuota(
        id = "quota_2026-11_Q2_todas_las_sucursales",
        title = "2ª Quincena · Noviembre 2026",
        startDate = "2026-11-16",
        endDate = "2026-11-30",
        totalDays = 15L,
        periodId = "2026-11_Q2",
        branchName = BranchOptions.ALL_BRANCHES_OPTION,
        targetGlobalSales = 900_000.0,
        targetCreditSales = 500_000.0,
        targetNewCustomers = 120L,
        targetAppMaOperations = 180L,
        targetNewCustomerRequests = 210L,
        active = true
    )

    private val branch87Quota = BiweeklyQuota(
        id = "quota_2026-11_Q2_sucursal_87",
        title = "2ª Quincena · Noviembre 2026",
        startDate = "2026-11-16",
        endDate = "2026-11-30",
        totalDays = 15L,
        periodId = "2026-11_Q2",
        branchName = "Sucursal 87",
        targetGlobalSales = 100_000.0,
        targetCreditSales = 60_000.0,
        targetNewCustomers = 15L,
        targetAppMaOperations = 20L,
        targetNewCustomerRequests = 25L,
        active = true
    )

    private val branch107Quota = BiweeklyQuota(
        id = "quota_2026-11_Q2_sucursal_107",
        title = "2ª Quincena · Noviembre 2026",
        startDate = "2026-11-16",
        endDate = "2026-11-30",
        totalDays = 15L,
        periodId = "2026-11_Q2",
        branchName = "Sucursal 107",
        targetGlobalSales = 140_000.0,
        targetCreditSales = 80_000.0,
        targetNewCustomers = 20L,
        targetAppMaOperations = 30L,
        targetNewCustomerRequests = 35L,
        active = true
    )

    @Test
    fun `resolveIndependentGeneralQuota never returns single branch quota or sums branches`() {
        val branchOnlyQuotas = listOf(branch87Quota, branch107Quota)
        assertNull(
            ProjectionCalculator.resolveIndependentGeneralQuota(
                quotas = branchOnlyQuotas,
                currentPeriodId = "2026-11_Q2"
            )
        )

        val resolved = ProjectionCalculator.resolveIndependentGeneralQuota(
            quotas = listOf(branch87Quota, generalQuota, branch107Quota),
            currentPeriodId = "2026-11_Q2"
        )
        assertEquals(generalQuota.id, resolved?.id)
        assertEquals(900_000.0, resolved?.targetGlobalSales ?: 0.0, 0.01)
    }

    @Test
    fun `computeAdminGeneralIndicatorsSummary keeps independent targets and sums all branches without double counting`() {
        val users = listOf(
            UserProfile(userId = "u87", displayName = "Sucursal 87", branchName = "Sucursal 87"),
            UserProfile(userId = "u107", displayName = "Sucursal 107", branchName = "Sucursal 107")
        )
        val entries = listOf(
            DailySalesEntry(
                id = "e87_older",
                userId = "u87",
                userName = "Sucursal 87",
                branchName = "Sucursal 87",
                quotaId = branch87Quota.id,
                dateString = "2026-11-26",
                globalSales = 10_000.0,
                creditSales = 5_000.0,
                newCustomers = 1L,
                appMaOperations = 2L,
                newCustomerRequests = 3L,
                updatedAt = Timestamp(1000L, 0)
            ),
            DailySalesEntry(
                id = "e87_latest",
                userId = "u87",
                userName = "Sucursal 87",
                branchName = "Sucursal 87",
                quotaId = branch87Quota.id,
                dateString = "2026-11-26",
                globalSales = 35_000.0,
                creditSales = 20_000.0,
                newCustomers = 5L,
                appMaOperations = 8L,
                newCustomerRequests = 9L,
                updatedAt = Timestamp(2000L, 0)
            ),
            DailySalesEntry(
                id = "e107_day1",
                userId = "u107",
                userName = "Sucursal 107",
                branchName = "Sucursal 107",
                quotaId = branch107Quota.id,
                dateString = "2026-11-20",
                globalSales = 45_000.0,
                creditSales = 25_000.0,
                newCustomers = 6L,
                appMaOperations = 10L,
                newCustomerRequests = 12L
            ),
            // Outside 2ª quincena de noviembre (must be excluded)
            DailySalesEntry(
                id = "e107_prev_q",
                userId = "u107",
                userName = "Sucursal 107",
                branchName = "Sucursal 107",
                quotaId = branch107Quota.id,
                dateString = "2026-11-15",
                globalSales = 99_000.0,
                creditSales = 99_000.0
            )
        )

        val summary = ProjectionCalculator.computeAdminGeneralIndicatorsSummary(
            quotas = listOf(generalQuota, branch87Quota, branch107Quota),
            allBranchEntries = entries,
            users = users,
            uid = "admin_uid",
            todayIso = "2026-11-26"
        )

        // Independent general targets (NOT 100k + 140k = 240k)
        val global = summary.metrics.first { it.metric == SalesMetricType.GLOBAL_SALES }
        val credit = summary.metrics.first { it.metric == SalesMetricType.CREDIT_SALES }
        val customers = summary.metrics.first { it.metric == SalesMetricType.NEW_CUSTOMERS }
        val appMa = summary.metrics.first { it.metric == SalesMetricType.APP_MA_OPS }
        val requests = summary.metrics.first { it.metric == SalesMetricType.NEW_CUSTOMER_REQUESTS }

        assertEquals(900_000.0, global.targetTotal, 0.01)
        assertEquals(500_000.0, credit.targetTotal, 0.01)
        assertEquals(120.0, customers.targetTotal, 0.01)
        assertEquals(180.0, appMa.targetTotal, 0.01)
        assertEquals(210.0, requests.targetTotal, 0.01)

        // Real actuals = sum across all branches (deduped for Sucursal 87 on 2026-11-26)
        assertEquals(80_000.0, global.actualTotal, 0.01)
        assertEquals(45_000.0, credit.actualTotal, 0.01)
        assertEquals(11.0, customers.actualTotal, 0.01)
        assertEquals(18.0, appMa.actualTotal, 0.01)
        assertEquals(21.0, requests.actualTotal, 0.01)
        assertEquals(2, summary.entriesCount)
    }

    @Test
    fun `buildBranchSalesSummaries classifies branch pace as ON_TRACK, MODERATE_RISK, and BEHIND using biweekly cycle`() {
        // 2026-11-20 is day 5 of 15 in 2026-11_Q2 (Nov 16..30), remaining = 10 days
        val q87 = branch87Quota.copy(targetGlobalSales = 150_000.0) // daily target = 10,000/day
        val q107 = branch107Quota.copy(targetGlobalSales = 150_000.0)
        val q109 = BiweeklyQuota(
            id = "q109",
            startDate = "2026-11-16",
            endDate = "2026-11-30",
            totalDays = 15L,
            periodId = "2026-11_Q2",
            branchName = "Sucursal 109",
            targetGlobalSales = 150_000.0,
            active = true
        )
        val users = listOf(
            UserProfile(userId = "u87", branchName = "Sucursal 87"),
            UserProfile(userId = "u107", branchName = "Sucursal 107"),
            UserProfile(userId = "u109", branchName = "Sucursal 109")
        )
        val entries = listOf(
            // Sucursal 87: 55,000 in 5 days -> 11,000/day -> proj 165,000 >= 150,000 -> ON_TRACK (Verde)
            DailySalesEntry(id = "e87", userId = "u87", branchName = "Sucursal 87", dateString = "2026-11-20", globalSales = 55_000.0),
            // Sucursal 107: 45,000 in 5 days -> 9,000/day -> proj 135,000 (90%) -> MODERATE_RISK (Ámbar)
            DailySalesEntry(id = "e107", userId = "u107", branchName = "Sucursal 107", dateString = "2026-11-20", globalSales = 45_000.0),
            // Sucursal 109: 30,000 in 5 days -> 6,000/day -> proj 90,000 (60%) -> BEHIND (Rojo)
            DailySalesEntry(id = "e109", userId = "u109", branchName = "Sucursal 109", dateString = "2026-11-20", globalSales = 30_000.0)
        )

        val summaries = buildBranchSalesSummaries(
            branches = listOf("Sucursal 87", "Sucursal 107", "Sucursal 109"),
            quotas = listOf(q87, q107, q109),
            entries = entries,
            teamUsers = users,
            todayIso = "2026-11-20",
            currentPeriodId = "2026-11_Q2"
        )

        assertEquals(ProjectionPace.ON_TRACK, summaries[0].pace)
        assertEquals(165_000.0, summaries[0].projectedGlobalSales, 0.01)
        assertEquals(11_000.0, summaries[0].dailyAverage, 0.01)
        assertEquals(10, summaries[0].remainingDays)

        assertEquals(ProjectionPace.MODERATE_RISK, summaries[1].pace)
        assertEquals(135_000.0, summaries[1].projectedGlobalSales, 0.01)

        assertEquals(ProjectionPace.BEHIND, summaries[2].pace)
        assertEquals(90_000.0, summaries[2].projectedGlobalSales, 0.01)
    }

    @Test
    fun `computeAdminWeightedProjection weights quotas and evaluates surplus vs deficit against independent admin target`() {
        // 2026-11-20 is day 5 of 15 in Q2
        val adminIndependentQuota = BiweeklyQuota(
            id = "quota_admin",
            startDate = "2026-11-16",
            endDate = "2026-11-30",
            totalDays = 15L,
            periodId = "2026-11_Q2",
            branchName = BranchOptions.ALL_BRANCHES_OPTION,
            targetGlobalSales = 400_000.0,
            active = true
        )
        // High-quota store (75% weight): target 300k; low-quota store (25% weight): target 100k
        val q87 = branch87Quota.copy(targetGlobalSales = 300_000.0)
        val q107 = branch107Quota.copy(targetGlobalSales = 100_000.0)
        val users = listOf(
            UserProfile(userId = "u87", branchName = "Sucursal 87"),
            UserProfile(userId = "u107", branchName = "Sucursal 107")
        )

        // Case 1: High-quota store projects 360k (+60k), low-quota store projects 60k (-40k).
        // Naive % avg = (120% + 60%) / 2 = 90%, but quota-weighted = 420k / 400k = 105% -> ON_TRACK!
        val entriesPositiveNet = listOf(
            DailySalesEntry(id = "e87", userId = "u87", branchName = "Sucursal 87", dateString = "2026-11-20", globalSales = 120_000.0),
            DailySalesEntry(id = "e107", userId = "u107", branchName = "Sucursal 107", dateString = "2026-11-20", globalSales = 20_000.0)
        )
        val weightedGreen = ProjectionCalculator.computeAdminWeightedProjection(
            metric = SalesMetricType.GLOBAL_SALES,
            quotas = listOf(adminIndependentQuota, q87, q107),
            allBranchEntries = entriesPositiveNet,
            users = users,
            adminGeneralQuota = adminIndependentQuota,
            todayIso = "2026-11-20",
            branches = listOf("Sucursal 87", "Sucursal 107")
        )
        assertEquals(ProjectionPace.ON_TRACK, weightedGreen.pace)
        assertTrue(weightedGreen.surplusCoversDeficit)
        assertEquals(60_000.0, weightedGreen.positiveSurplusTotal, 0.01)
        assertEquals(40_000.0, weightedGreen.negativeDeficitTotal, 0.01)
        assertEquals(20_000.0, weightedGreen.netBalanceVsAdminQuota, 0.01)
        assertEquals(1.05f, weightedGreen.weightedBranchProjectedRatio, 0.001f)
        assertEquals(0.75f, weightedGreen.branchOutcomes[0].quotaWeightShare, 0.001f)
        assertEquals(0.25f, weightedGreen.branchOutcomes[1].quotaWeightShare, 0.001f)

        // Case 2: Surplus (+20k) does not cover deficit (-60k) -> net -40k (90% of 400k) -> MODERATE_RISK (Ámbar)
        val entriesModerate = listOf(
            DailySalesEntry(id = "e87", userId = "u87", branchName = "Sucursal 87", dateString = "2026-11-20", globalSales = 106_666.67),
            DailySalesEntry(id = "e107", userId = "u107", branchName = "Sucursal 107", dateString = "2026-11-20", globalSales = 13_333.33)
        )
        val weightedAmber = ProjectionCalculator.computeAdminWeightedProjection(
            metric = SalesMetricType.GLOBAL_SALES,
            quotas = listOf(adminIndependentQuota, q87, q107),
            allBranchEntries = entriesModerate,
            users = users,
            adminGeneralQuota = adminIndependentQuota,
            todayIso = "2026-11-20",
            branches = listOf("Sucursal 87", "Sucursal 107")
        )
        assertEquals(ProjectionPace.MODERATE_RISK, weightedAmber.pace)
        assertFalse(weightedAmber.surplusCoversDeficit)
        assertEquals(-40_000.0, weightedAmber.netBalanceVsAdminQuota, 1.0)

        // Case 3: Severe deficit -> projected 240k (60% of 400k) -> BEHIND (Rojo)
        val entriesBehind = listOf(
            DailySalesEntry(id = "e87", userId = "u87", branchName = "Sucursal 87", dateString = "2026-11-20", globalSales = 70_000.0),
            DailySalesEntry(id = "e107", userId = "u107", branchName = "Sucursal 107", dateString = "2026-11-20", globalSales = 10_000.0)
        )
        val weightedRed = ProjectionCalculator.computeAdminWeightedProjection(
            metric = SalesMetricType.GLOBAL_SALES,
            quotas = listOf(adminIndependentQuota, q87, q107),
            allBranchEntries = entriesBehind,
            users = users,
            adminGeneralQuota = adminIndependentQuota,
            todayIso = "2026-11-20",
            branches = listOf("Sucursal 87", "Sucursal 107")
        )
        assertEquals(ProjectionPace.BEHIND, weightedRed.pace)
        assertFalse(weightedRed.surplusCoversDeficit)
        assertEquals(-160_000.0, weightedRed.netBalanceVsAdminQuota, 0.01)
    }
}
